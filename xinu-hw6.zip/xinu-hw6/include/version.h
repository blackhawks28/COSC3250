#define VERSION "(Embedded Xinu) (arm-rpi3) #2014 (cpiszczek@morbius) Wed Mar 10 21:08:55 CST 2021"
