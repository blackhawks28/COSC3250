/**
 * @file testcases.c
 * @provides testcases
 *
 *
 * Modified by:	
 *
 * TA-BOT:MAILTO 
 *
 */
/**
* COSC 3250 - Project 6
* Test cases for the roundrobin scheduler
* @authors [Chris Piszczek]
* @authors [Dennis Burmeister]
* Instructor [Dr. Rubya]
* TA-BOT:MAILTO [christian.piszczek@marquette.edu]
* TA-BOT:MAILTO [dennis.burmeister@marquette.edu]
*/
/* Embedded XINU, Copyright (C) 2007.  All rights reserved. */

#include <xinu.h>

void printpid(int times)
{
    int i = 0;
    uint cpuid = getcpuid();

    enable();
    for (i = 0; i < times; i++)
    {
        kprintf("This is process %d\r\n", currpid[cpuid]);
        udelay(1);
    }
}
void infinite(void){
    int x = 1;
    enable();
    while(x == 1){
        kprintf("This is an infinite loop called loop 1 because blah blah nothing is working.\r\n");
        udelay(1);
    }
}

/**
 * testcases - called after initialization completes to test things.
 */
void testcases(void)
{
    uchar c;

    kprintf("===TEST BEGIN===\r\n");
    kprintf("0) Test priority scheduling\r\n");
    kprintf("\'A\') Aging / Starvation testcase\r\n");
    kprintf("\'P\') Preemption testcase\r\n");

    // TODO: Test your operating system!

    c = kgetc();
    switch (c)
    {
    case '0':
         //Run 3 processes with varying priorities

        ready(create((void *)printpid, INITSTK, PRIORITY_HIGH, "PRINTER-A", 1, 5), RESCHED_NO, 0);
        ready(create((void *)printpid, INITSTK, PRIORITY_HIGH, "PRINTER-B", 1, 5), RESCHED_NO, 0);
        ready(create((void *)printpid, INITSTK, PRIORITY_LOW, "PRINTER-C", 1, 5), RESCHED_YES, 0);

        break;

    case 'a':
    case 'A':
#if AGING

        // AGING TESTCASE

        //create process A that runs an infinite loop, run it on core 0(if PREEMPT is false, it wont leave core 0)(high priority)
        //create process B that runs printpid(high priority)

        //for aging, create process C that runs printpid(low priority) process C will never run if priority boosting isnt implemented properly

        kprintf("AGING is enabled.\r\n");

        // TODO: Create a testcase that demonstrates aging
        ready(create((void *)infinite, INITSTK, PRIORITY_HIGH, "PROCESS-A", 1, NULL), RESCHED_NO, 0);
        ready(create((void *)printpid, INITSTK, PRIORITY_HIGH, "PROCCESS-B", 1, 200), RESCHED_NO, 0);

        ready(create((void *)printpid, INITSTK, PRIORITY_MED, "PROCCESS-B2", 1, 50), RESCHED_NO, 0);
        ready(create((void *)printpid, INITSTK, PRIORITY_LOW, "PROCCESS-C", 1, 5), RESCHED_YES, 0);



#else
        // STARVING TESTCASE
        kprintf("\r\nAGING is not currently enabled.\r\n");

        // TODO: Create a testcase that demonstrates starvation
        //since aging is disabled the medium priority process will never run.
            ready(create((void *)infinite, INITSTK, PRIORITY_HIGH, "PROCESS-A", 1, NULL), RESCHED_NO, 0);
            ready(create((void *)printpid, INITSTK, PRIORITY_MED, "PROCESS-B", 1, 5), RESCHED_YES, 0);

#endif
        break;

    case 'p':
    case 'P':
#if PREEMPT
        // PREEMPTION TESTCASE

        //When preemption is set to true then the processes should age, and since the aging relies on the preemption decrementing,
        //than that means that preemption works.
        kprintf("\r\nPreemption is enabled.\r\n");
        //ready(create((void *)infinite, INITSTK, PRIORITY_HIGH, "INFINITE1", 1, NULL), RESCHED_NO, 0);
        ready(create((void *)printpid, INITSTK, PRIORITY_HIGH, "PROCESS-B", 1, 20), RESCHED_NO, 0);
        ready(create((void *)printpid, INITSTK, PRIORITY_HIGH, "PROCESS-B", 1, 20), RESCHED_YES, 0);


        // TODO: Create a testcase that demonstrates preemption


#else
        kprintf("\r\nPreemption is not currently enabled...\r\n");
#endif
        break;

    default:
        break;
    }

    kprintf("\r\n===TEST END===\r\n");
    return;
}
