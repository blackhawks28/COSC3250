#define VERSION "(Embedded Xinu) (arm-rpi3) #2124 (cpiszczek@morbius) Wed Mar 31 10:17:04 CDT 2021"
