/**
 * @file recv.c
 * @provides recv.
 *
 * $Id: receive.c 2020 2009-08-13 17:50:08Z mschul $
 */
/**
* COSC 3250 - Project 8
* Receives message from process
* @authors [Chris Piszczek]
* @authors [Dennis Burmeister]
* Instructor [Dr. Rubya]
* TA-BOT:MAILTO [christian.piszczek@marquette.edu]
* TA-BOT:MAILTO [dennis.burmeister@marquette.edu]
*/
/* Embedded Xinu, Copyright (C) 2009.  All rights reserved. */

#include <xinu.h>

/**
 * recv - wait for a mesage and return it
 * @return message
 */

message recv(void)
{
	register pcb *ppcb;
	int senderpid = -1;
	message msg;
	ppcb = &proctab[currpid[getcpuid()]];
	
	/* TODO:
 	* - Remember to acquire lock and release lock when interacitng with the msg structure
 	* - Check for Message. If no message, put in blocking state and reschedule
 	*   			If there is message, retrive message
 	* - Now, check queue for wating send processes,
 	*   If stuff in queue  collect message for next time recv is called and ready send process
 	*   else, reset message flag
 	*   return collected message
 	*/

	//check hasmessage
	//if it is false
		//change state to PRRECV
		//resched()

	//msg=ppcb->msg_var.msgin

	//if msgqueue is not empty
		//senderpid from msgqueue (dequeue)
		//set msgin= sender's msgout
		//reset sender's msgout
		//make the sender ready (senderpid)
	//reset hasmessage

	//return msg(msgin);

	//register pcb *hold;
	//hold = &proctab[senderpid];
	lock_acquire(ppcb->msg_var.core_com_lock);
	if(ppcb->msg_var.hasMessage == FALSE){
		ppcb->state = PRRECV;
		lock_release(ppcb->msg_var.core_com_lock);//just added release lock before rescheding in send.c

		resched();
		lock_acquire(ppcb->msg_var.core_com_lock);//added
	}
	else {
		msg = ppcb->msg_var.msgin;
	}
	if(isempty(ppcb->msg_var.msgqueue) == FALSE){

		register pcb *hold;
		senderpid = dequeue(ppcb->msg_var.msgqueue);

		if(senderpid == -1){
			lock_release(ppcb->msg_var.core_com_lock);
			return SYSERR;
		}

		hold = &proctab[senderpid];
		//i think you set ppcb pid to senderpid
		//ppcb = &proctab[senderpid]; //added this with thought that if there is something in msgqueue then dequeueing it will give pid of process
		//Then resetting ppcb with new pid allows for proper message to be obtained below.

		lock_acquire(hold->msg_var.core_com_lock);//mess with msg_var of hold so choosing to lock it
		ppcb->msg_var.msgin = hold->msg_var.msgout;
		hold->msg_var.msgout = NULL;
		hold->state = PRREADY;

		lock_release(ppcb->msg_var.core_com_lock);
		lock_release(hold->msg_var.core_com_lock);
		ready(senderpid, RESCHED_NO, hold->core_affinity);
		lock_acquire(ppcb->msg_var.core_com_lock);//added
	}
	ppcb->msg_var.hasMessage = FALSE;

	lock_release(ppcb->msg_var.core_com_lock);
	return msg;
}
