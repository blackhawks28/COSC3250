 /**
 * @file send.c
 * @provides send
 *
 * $Id: send.c 2020 2009-08-13 17:50:08Z mschul $
 */
 /**
* COSC 3250 - Project 8
* Send message to from process to other process
* @authors [Chris Piszczek]
* @authors [Dennis Burmeister]
* Instructor [Dr. Rubya]
* TA-BOT:MAILTO [christian.piszczek@marquette.edu]
* TA-BOT:MAILTO [dennis.burmeister@marquette.edu]
*/
/* Embedded Xinu, Copyright (C) 2009.  Al rights resered. */

#include <xinu.h>

/**
 * Send a message to another therad
 * @param pid proc id of recipient
 * @param msg contents of message
 * @return OK on sucess, SYSERR on failure
 */
syscall send(int pid, message msg)
{
	register pcb *spcb;//sender pcb; current process.
	register pcb *rpcb;//receiver pcb
	
	/*TODO:
 	* - PID Error checking
 	* - Acquire receiving process lock (remember to release when appropriate!
 	* - Retrieving Process Error Checking
 	* - If receiving process has message, block sending process and put msg in msgout and call resched
 	* - Else, deposit message, change message flag and, if receiving process is blocking, ready it.
 	* - return ok.
 	*/

	//check if the state is not PRFREE, return syserr


	//check if receiver's hasmessage is true/false
	//if true then it already has a message
		//change the state spcb->state=PRSEND
		//spcb->msgout=msg
		//enqueue(sender's pid , rpcb->msgqueue)
		//resched() since it is in blocking state
	//if false
		//see sendnow()
	rpcb = &proctab[pid];
	spcb = &proctab[currpid[getcpuid()]];


	if(isbadpid(pid) == TRUE){
		return SYSERR;
	}
	lock_acquire(rpcb->msg_var.core_com_lock);
	if(rpcb->state == PRFREE){
		lock_release(rpcb->msg_var.core_com_lock);
		return SYSERR;
	}

	if(rpcb->msg_var.hasMessage == TRUE){
		lock_acquire(spcb->msg_var.core_com_lock);

		spcb->state = PRSEND;
		spcb->msg_var.msgout = msg;


		enqueue(currpid[getcpuid()], rpcb->msg_var.msgqueue);

		lock_release(rpcb->msg_var.core_com_lock);
		lock_release(spcb->msg_var.core_com_lock);

		resched();

		lock_acquire(rpcb->msg_var.core_com_lock);//added
		lock_acquire(spcb->msg_var.core_com_lock);//added

	}
	else{
		rpcb->msg_var.msgin = msg;
		rpcb->msg_var.hasMessage = TRUE;
		if(rpcb->state == PRRECV){
			rpcb->state = PRREADY;
			lock_release(rpcb->msg_var.core_com_lock);
			lock_release(spcb->msg_var.core_com_lock);//added
			ready(pid, RESCHED_YES, rpcb->core_affinity);//changed from RESCHED_NO to RESCHED_YES
			lock_acquire(rpcb->msg_var.core_com_lock);//added
		}
	}
	lock_release(rpcb->msg_var.core_com_lock);
	return OK;
}
