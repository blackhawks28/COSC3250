#define VERSION "(Embedded Xinu) (arm-rpi3) #2612 (cpiszczek@morbius) Tue Apr 13 13:56:39 CDT 2021"
