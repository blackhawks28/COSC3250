#define VERSION "(Embedded Xinu) (arm-rpi3) #2345 (cpiszczek@morbius) Wed Apr 7 11:32:41 CDT 2021"
