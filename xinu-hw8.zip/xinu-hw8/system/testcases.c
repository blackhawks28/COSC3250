/**
 * @file testcases.c
 * @provides testcases
 *
 *
 * Modified by:	
 *
 * TA-BOT:MAILTO 
 *
 */
/**
* COSC 3250 - Project 7
* Test cases project 7
* @authors [Chris Piszczek]
* @authors [Dennis Burmeister]
* Instructor [Dr. Rubya]
* TA-BOT:MAILTO [christian.piszczek@marquette.edu]
* TA-BOT:MAILTO [dennis.burmeister@marquette.edu]
*/
/* Embedded XINU, Copyright (C) 2007.  All rights reserved. */

#include <xinu.h>
#include <stdio.h>

void printpid(int times)
{
    int i = 0;
    uint cpuid = getcpuid();

    enable();
    for (i = 0; i < times; i++)
    {
        kprintf("This is process %d\r\n", currpid[cpuid]);
        udelay(1);
    }
}
void infinite(void){
    int x = 1;
    enable();
    while(x == 1){
        kprintf("This is an infinite loop called loop 1 because blah blah nothing is working.\r\n");
        udelay(1);
    }
}

//void printlist(void){
//    enable();
//    int cpuid = getcpuid();
//    while(((memblk *)(freelist[0].head)->next) != freelist[0].bound){
//        kprintf("%d",freelist[0]);
//        (memblk *)(freelist[0].head)->next;
//    }
//}

void recMsg(void){
    //kprintf("%d",recv());
    recv();
}

/**
 * testcases - called after initialization completes to test things.
 */
void testcases(void)
{
    int newpid;
    int counter = 0;
    int message;
    uint cpuid = getcpuid();
   volatile int pid;
   volatile int pid2;
    volatile int testpid;
    pcb *ppcb;
    pcb *ppcb2;
    void *mempointer;
    uchar c;
    enable();

    kprintf("===TEST BEGIN===\r\n");
    kprintf("0) Test priority scheduling\r\n");
    kprintf("4) Simply send message instantly and see if it receives it instantly\r\n");
    kprintf("\'A\') Aging / Starvation testcase\r\n");
    kprintf("\'P\') Preemption testcase\r\n");

    // TODO: Test your operating system!

    c = kgetc();
    switch (c)
    {
    case '0':
         //Run 3 processes with varying priorities

        ready(create((void *)printpid, INITSTK, PRIORITY_HIGH, "PRINTER-A", 1, 5), RESCHED_NO, 0);
        ready(create((void *)printpid, INITSTK, PRIORITY_HIGH, "PRINTER-B", 1, 5), RESCHED_NO, 0);
        ready(create((void *)printpid, INITSTK, PRIORITY_LOW, "PRINTER-C", 1, 5), RESCHED_YES, 0);

        break;

        case '1':
            mempointer = malloc(4);
            //kprintf("%d",malloc(4));
            //kprintf("%d",malloc(4));
            //kprintf("%d",free(mempointer));
            //kprintf("%d",free(mempointer));
            //printlist();
            //int *current_node = freelist[0].head;
            //mempointer = malloc(4);
            //kprintf("%d",malloc(0));

            kprintf("%d\n",freelist[0]);
            kprintf("%d\n",freelist[0].head);
            kprintf("%d\n",(memblk *)(freelist[0].head)->next);
            kprintf("%d\n",getmem(4));
            //kprintf("%d\n",malloc(4));
            kprintf("%d\n",freelist[0].head);
            kprintf("%d\n",freelist[0]);
            kprintf("%d\n",freemem(mempointer,4));
            kprintf("%d\n",free(mempointer));
            //kprintf("%d\n",freelist[0].head);
            //kprintf("%d\n",(memblk *)(freelist[0].head)->next);
            //kprintf("%d\n",(memblk *)(freelist[0].head)->next);
           // printlist();
            break;

        case '2':
            testpid = create((void *)recMsg, INITSTK, PRIORITY_LOW, "SIMPLE INSTANT SEND AND RECEIVE",1,1);
            //pid = currpid[cpuid];
            ppcb = &proctab[testpid];
            ppcb->core_affinity = 0;
            message = 1234;
            int result = sendnow(testpid, message);
            kprintf("Result: %d", result);

            if((ppcb->msg_var.hasMessage == TRUE) && (ppcb->msg_var.msgin == message)){
                kprintf("Message properly sent.\r\n");
            }
            else{
                kprintf("recvnow process has message = %d, msgin = %d\r\n", ppcb->msg_var.hasMessage, ppcb->msg_var.msgin);
            }
            //kill(pid);

            break;

        case '3':

            //kprintf("Enter 1 if you want 10 to be printed, and 0 if you don't want it to be printed: ");
            //userinput = c;
            pid = create((void *)recMsg, INITSTK, PRIORITY_LOW, "SIMPLE INSTANT SEND AND RECEIVE",1,1);
            ppcb = &proctab[pid];
            ppcb->core_affinity = 0;
            sendnow(pid,1);

            //recMsg();

            kill(pid);
            break;

        case '4':
            create((void *)recMsg, INITSTK, PRIORITY_LOW, "SIMPLE INSTANT SEND AND RECEIVE",1,1);
            pid = currpid[cpuid];
            kprintf("%d\r\n",sendnow(pid,453));
            kprintf("%d\r\n",recvnow());

            break;

        case '5':

            pid = create((void *)printpid, INITSTK, PRIORITY_HIGH, "SIMPLE INSTANT SEND AND RECEIVE",1,100);


            //pid = currpid[cpuid];
            ppcb = &proctab[pid];
            ppcb->core_affinity = 0;
            kprintf("%d\r\n",send(pid,111));
            counter++;
            if(counter == 1){
                pid = create((void *)printpid, INITSTK, PRIORITY_HIGH, "SIMPLE INSTANT SEND AND RECEIVE",1,100);
                //pid = currpid[cpuid];
                kprintf("%d\r\n",send(pid,222));
                counter++;
            }
            if(counter == 2){
                pid = create((void *)printpid, INITSTK, PRIORITY_LOW, "SIMPLE INSTANT SEND AND RECEIVE",1,10);
                //pid = currpid[cpuid];
                kprintf("%d\r\n",send(pid,333));
            }
            kprintf("%d\r\n",recv());
            kill(pid);


            break;

        case '6':
            pid = create((void *)recMsg, INITSTK, PRIORITY_HIGH, "SIMPLE INSTANT SEND AND RECEIVE",1,100);
            ppcb = &proctab[pid];
            ppcb->core_affinity = 0;

            kprintf("%d\r\n",send(pid,-4723));
            kprintf("%d\r\n",ppcb->msg_var.msgin);


            kill(pid);
            break;
        case '7':

            testpid = create((void *)recMsg, INITSTK, PRIORITY_HIGH, "SIMPLE INSTANT SEND AND RECEIVE",1,100);
            ppcb = &proctab[testpid];
            ppcb->core_affinity = 0;

            kprintf("%d\r\n",send(testpid,100));
            //kprintf("%d\r\n",send(testpid,300));
            //kprintf("%d\r\n",send(testpid,-4723));

            newpid = dequeue(ppcb->msg_var.msgqueue);
            ppcb2 = &proctab[newpid];
            kprintf("Dequeue Result: %d\r\n",ppcb2->msg_var.msgout);
            kill(testpid);

            break;
    case 'a':
    case 'A':
#if AGING

        // AGING TESTCASE

        //create process A that runs an infinite loop, run it on core 0(if PREEMPT is false, it wont leave core 0)(high priority)
        //create process B that runs printpid(high priority)

        //for aging, create process C that runs printpid(low priority) process C will never run if priority boosting isnt implemented properly

        kprintf("AGING is enabled.\r\n");

        // TODO: Create a testcase that demonstrates aging
        ready(create((void *)infinite, INITSTK, PRIORITY_HIGH, "PROCESS-A", 1, NULL), RESCHED_NO, 0);
        ready(create((void *)printpid, INITSTK, PRIORITY_HIGH, "PROCCESS-B", 1, 200), RESCHED_NO, 0);

        ready(create((void *)printpid, INITSTK, PRIORITY_MED, "PROCCESS-B2", 1, 50), RESCHED_NO, 0);
        ready(create((void *)printpid, INITSTK, PRIORITY_LOW, "PROCCESS-C", 1, 5), RESCHED_YES, 0);



#else
        // STARVING TESTCASE
        kprintf("\r\nAGING is not currently enabled.\r\n");

        // TODO: Create a testcase that demonstrates starvation
        //since aging is disabled the medium priority process will never run.
            ready(create((void *)infinite, INITSTK, PRIORITY_HIGH, "PROCESS-A", 1, NULL), RESCHED_NO, 0);
            ready(create((void *)printpid, INITSTK, PRIORITY_MED, "PROCESS-B", 1, 5), RESCHED_YES, 0);

#endif
        break;

    case 'p':
    case 'P':
#if PREEMPT
        // PREEMPTION TESTCASE

        //When preemption is set to true then the processes should age, and since the aging relies on the preemption decrementing,
        //than that means that preemption works.
        kprintf("\r\nPreemption is enabled.\r\n");
        //ready(create((void *)infinite, INITSTK, PRIORITY_HIGH, "INFINITE1", 1, NULL), RESCHED_NO, 0);
        ready(create((void *)printpid, INITSTK, PRIORITY_HIGH, "PROCESS-B", 1, 20), RESCHED_NO, 0);
        ready(create((void *)printpid, INITSTK, PRIORITY_HIGH, "PROCESS-B", 1, 20), RESCHED_YES, 0);


        // TODO: Create a testcase that demonstrates preemption


#else
        kprintf("\r\nPreemption is not currently enabled...\r\n");
#endif
        break;

    default:
        break;
    }

    kprintf("\r\n===TEST END===\r\n");
    return;
}
