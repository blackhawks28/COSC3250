/**
 * @file recvnow.c
 * @provides recvnow
 *
 */
/**
* COSC 3250 - Project 8
* Receives message to from process immediately
* @authors [Chris Piszczek]
* @authors [Dennis Burmeister]
* Instructor [Dr. Rubya]
* TA-BOT:MAILTO [christian.piszczek@marquette.edu]
* TA-BOT:MAILTO [dennis.burmeister@marquette.edu]
*/
/* Embedded Xinu, Copyright (C) 2020.  All rights resered. */

#include <xinu.h>

/**
 * recvnow - return pre-stored message, or immediate error.
 * @return message or SYSERR
 */

message recvnow(void)
{
	register pcb *ppcb;
	message msg;

	ppcb = &proctab[currpid[getcpuid()]];
	
	/* TODO:
 	* - Acquire and release lock when working in msg structure
 	* - check for message, if no messsage, error
 	*   		       else, retrieve & return message
 	*/

	//if hasmessage == true/false
	//if false then return error
	//if true msg=process's msgin
	//reset hasmessage to false
	//return msg

	lock_acquire(ppcb->msg_var.core_com_lock);
	if(ppcb->msg_var.hasMessage == FALSE){
		lock_release(ppcb->msg_var.core_com_lock);
		return SYSERR;
	}
	else{
		msg = ppcb->msg_var.msgin;
		ppcb->msg_var.hasMessage = FALSE;
	}
	lock_release(ppcb->msg_var.core_com_lock);
	return msg;
}
