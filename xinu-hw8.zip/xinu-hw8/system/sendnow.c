/**
 * @file sendnow.c
 * @provides sendnow.
 *
 */
/**
* COSC 3250 - Project 8
* Send message to from process to other process immediately
* @authors [Chris Piszczek]
* @authors [Dennis Burmeister]
* Instructor [Dr. Rubya]
* TA-BOT:MAILTO [christian.piszczek@marquette.edu]
* TA-BOT:MAILTO [dennis.burmeister@marquette.edu]
*/
/* Embedded Xinu, Copyright (C) 2020.   All rights reserved. */

#include <xinu.h>

/**
 * Send a message to anoher thread
 * @param pid proc id of recipient
 * @param msg contents of message
 * @return OK on sucess, SYSERR on failure
 */

syscall sendnow(int pid, message msg)
{
	register pcb *ppcb;
	ppcb = &proctab[pid]; // reciever's pcb

	//check if badpid()
	//check if reciever's hasmessage is true/false
	//if true then it already has a message so return error
	//if false put message in reciever's msgin
		//set reciever's hasmessage to be true
		//if reciever's state is prrecv
			//change it to prready
			//ready(pid,.....,ppcb->core_affinity)

	/* TODO:
 	* - Acquire Lock and release when appropriate
 	* - PID & Process Error Checking
 	* - Deposit Message, raise flag
 	* -  If receving message is blocked, ready process
 	* - Return OK
 	*/
	
	lock_acquire(ppcb->msg_var.core_com_lock);
	if(isbadpid(pid) == TRUE || ppcb->msg_var.hasMessage == TRUE){
			lock_release(ppcb->msg_var.core_com_lock);
			return SYSERR;
		}
		else{
			ppcb->msg_var.msgin = msg;
			ppcb->msg_var.hasMessage = TRUE;
			if(ppcb->state == PRRECV){
				ppcb->state = PRREADY;
				ready(pid, RESCHED_NO, ppcb->core_affinity);
			}
		}
	lock_release(ppcb->msg_var.core_com_lock);
	return OK;
}
