/**
 * @file freemem.c
 *
 */
/**
* COSC 3250 - Project 7
* Frees the blocks of memory that were once being used.
* @authors [Chris Piszczek]
* @authors [Dennis Burmeister]
* Instructor [Dr. Rubya]
* TA-BOT:MAILTO [christian.piszczek@marquette.edu]
* TA-BOT:MAILTO [dennis.burmeister@marquette.edu]
*/
/* Embedded Xinu, Copyright (C) 2009.  All rights reserved. */

#include <xinu.h>

/**
 * @ingroup memory_mgmt
 *
 * Frees a block of heap-allocated memory.
 *
 * @param memptr
 *      Pointer to memory block allocated with memget().
 *
 * @param nbytes
 *      Length of memory block, in bytes.  (Same value passed to memget().)
 *
 * @return
 *      ::OK on success; ::SYSERR on failure.  This function can only fail
 *      because of memory corruption or specifying an invalid memory block.
 */

/*Worked with Calvin Schaul on part where determine proper cpuid*/
syscall freemem(void *memptr, ulong nbytes)
{
    register struct memblock *block, *next, *prev;
    irqmask im;
    ulong top;

    /* make sure block is in heap */
    if ((0 == nbytes)
        || ((ulong)memptr < (ulong)memheap)
        || ((ulong)memptr > (ulong)platform.maxaddr))
    {
        return SYSERR;
    }

    block = (struct memblock *)memptr;
    nbytes = (ulong)roundmb(nbytes);

    im = disable();

	/* TODO:
     *      - Determine correct freelist to return to
     *        based on block address
     *      - Acquire memory lock (memlock)
     *      - Find where the memory block should
     *        go back onto the freelist (based on address)
     *      - Find top of previous memblock
     *      - Make sure block is not overlapping on prev or next blocks
     *      - Coalesce with previous block if adjacent
     *      - Coalesce with next block if adjacent
     */

    int i;
    int cpuid = -1;
    for(i = 0; i < NCORES; i++){
        if((freelist[i].base <= (ulong)block) && ((freelist[i].base+freelist[i].bound) >= (ulong)block)){
            cpuid = i;
            break;
        }
    }
    if(cpuid == -1){
        restore(im);
        return SYSERR;
    }


    prev = (memblk *)&freelist[cpuid];
    next = freelist[cpuid].head;


    lock_acquire(freelist[cpuid].memlock);
    while(next != NULL && next < block){//goes through the freelist until it finds the memblock we are looking for.
        prev = next;
        next = next->next;
    }
    if(prev == (memblk *)&freelist[cpuid]){
        top = NULL;
    }
    else {
        top = (ulong)prev + prev->length;
    }
    if((top > (ulong)block) || ((next != NULL) && ((ulong)block+nbytes) > (ulong)next)){
        lock_release(freelist[cpuid].memlock);
        restore(im);
        return SYSERR;
    }
    freelist[cpuid].length = freelist[cpuid].length + nbytes;

    if(top == (ulong)block){//previous block compact
        prev->length = prev->length + nbytes;//sets the size of prev to its current length plus the number of bytes of memory we are freeing.
        block = prev;
    }
    else{
        block->next = next;
        block->length = nbytes;
        prev->next = block;
    }

    if((ulong)block + block->length == (ulong)next){//next block compact
        block->length = block->length + next->length;
        block->next = next->next;
    }
    lock_release(freelist[cpuid].memlock);
    restore(im);
    return OK;

}

