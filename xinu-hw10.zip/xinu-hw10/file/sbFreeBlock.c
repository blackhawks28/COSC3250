/* sbFreeBlock.c - sbFreeBlock */
/* Copyright (C) 2008, Marquette University.  All rights reserved. */
/**
* COSC 3250 - Project 10
* Takes the block that was used in memory for a file in the file system and frees it so it can be used again.
* @authors [Chris Piszczek]
* @authors [Dennis Burmeister]
* Instructor [Dr. Rubya]
* TA-BOT:MAILTO [christian.piszczek@marquette.edu]
* TA-BOT:MAILTO [dennis.burmeister@marquette.edu]
*/


#include <kernel.h>
#include <device.h>
#include <memory.h>
#include <disk.h>
#include <file.h>

/*------------------------------------------------------------------------
 * sbFreeBlock - Add a block back into the free list of disk blocks.
 *------------------------------------------------------------------------
 */
devcall sbFreeBlock(struct superblock *psuper, int block)
{
    // TODO: Add the block back into the filesystem's list of
    //  free blocks.  Use the superblock's locks to guarantee
    //  mutually exclusive access to the free list, and write
    //  the changed free list segment(s) back to disk.

    //list of free blocks in file.h, struct freeblock
    //use semaphore sb_freelock and sb_dirlock to guarantee mutual exclusivity
    //

    //check for errors, check psuper, the limit of block
    //define freeblk pointer, freeblk = psuper->sb_freelist

    struct freeblock *freeblk, *free;
    struct freeblock *swizzlehold1;
    struct dirblock *swizzlehold2;
    struct dentry *phw;
    int result, i;
    int diskfd;

    if (NULL == psuper)
    {
        return SYSERR;
    }
    phw = psuper->sb_disk;
    if (NULL == phw)
    {
        return SYSERR;
    }
    diskfd = phw - devtab;//current disk devtab-overall devtab

    wait(psuper->sb_freelock);
    freeblk = psuper->sb_freelst;
    if(NULL == freeblk)//if there is no superblock free list then we need to make one
    {
        free = malloc(sizeof(struct freeblock));//need to allocate memory for new freeblk that it being created.
        free->fr_blocknum = block;//sets the block number values in the free list to the file that was deleted.
        free->fr_count = 0;//setting the number of blocks to 0 since we're creating/adding it
        free->fr_next = NULL;//sets next free block to nothing since we are adding it to the end of the freelist list.

        psuper->sb_freelst = free;//after making freelist we set it to the superblocks free list
        freeblk = psuper->sb_freelst;//and set the freeblk to the superblock's freelist

        swizzlehold1 = psuper->sb_freelst;//hold onto the superblock freelist
        psuper->sb_freelst = (struct freeblock*)swizzlehold1->fr_blocknum;//set the superblock freelist to the freeblock's block number
        swizzlehold2 = psuper->sb_dirlst;//hold onto the superblock's file directory
        psuper->sb_dirlst = (struct dirblock*)swizzlehold2->db_blocknum;//set superblock's directory list to the directory's block number
        seek(diskfd, psuper->sb_blocknum);//looks for position on disk
        if(write(diskfd, psuper, sizeof(struct superblock)) == SYSERR){
            signal(psuper->sb_freelock);
            return SYSERR;
        }
        psuper->sb_freelst = swizzlehold1;//set the superblock freelist back to the actual freelist
        psuper->sb_dirlst = swizzlehold2;//set the superblock directory list back to the actual directory list.
        seek(diskfd, free->fr_blocknum);
        if(write(diskfd, free, sizeof(struct freeblock)) == SYSERR){
            signal(psuper->sb_freelock);
            return SYSERR;
        }
        signal(psuper->sb_freelock);
        return OK;
    }
    else{//CASE 2: if the last free block is full, so its capacity is at the number of collector nodes it can have, then add a new free block
         //and CASE 3: are tested in same if statement below while loop.
        //Case 3: if the first free block has any entries left; reason is there is a possibility that we truly only have one free block that has any collector node space available.
        while(freeblk->fr_next != NULL){
            freeblk = freeblk->fr_next;
        }
        if((freeblk->fr_count >= FREEBLOCKMAX) || ((freeblk->fr_count == 0) && (freeblk->fr_next == NULL) && (psuper->sb_freelst == freeblk))){//CASE 2: last freeblock is full so count is 0,and next doesnt exist ((freeblk->fr_count == 0) && (freeblk->fr_next == NULL) && (psuper->sb_freelst == freeblk)) ||||and||||| CASE 3: first freeblock has any entries left, it starts in first block (freeblk->fr_count >= FREEBLOCKMAX)
            free = malloc(sizeof(struct freeblock));//need to allocate memory for new freeblk that it being created.
            free->fr_blocknum = block;//sets the block number values in the free list to the file that was deleted.
            free->fr_count = 0;//setting the number of blocks to 0 since we're creating/adding it
            free->fr_next = NULL;//sets next free block to nothing since we are adding in a brand new list
            freeblk->fr_next = free;
            swizzlehold1 = freeblk->fr_next;//keeps track of the current next freeblock
            freeblk->fr_next = (struct freeblock*)swizzlehold1->fr_blocknum;//might have to cast to freeblock*?//sets the current next freeblock to the hold blocknumber

            seek(diskfd, freeblk->fr_blocknum);//find freeblock position on specific disk
            if(write(diskfd, freeblk, sizeof(struct freeblock)) == SYSERR){
                signal(psuper->sb_freelock);
                return SYSERR;
            }
            freeblk->fr_next = swizzlehold1;//sets the next freeblock to what it actually should be
            seek(diskfd,free->fr_blocknum);
            if(write(diskfd, free, sizeof(struct freeblock)) == SYSERR){
                signal(psuper->sb_freelock);
                return SYSERR;
            }
            signal(psuper->sb_freelock);
            return OK;
        }
        else{//Otherwise if you go through the freelist and case 2 or 3 don't occur
            freeblk->fr_free[freeblk->fr_count] = block;//set the free array to the value of the block
            freeblk->fr_count++;// increment for next time it needs to be added
            seek(diskfd, freeblk->fr_blocknum);//find position on disk
            if(write(diskfd, freeblk, sizeof(struct freeblock)) == SYSERR){//right to it
                signal(psuper->sb_freelock);
                return SYSERR;
            }
            signal(psuper->sb_freelock);//unlock
            return OK;
        }

    }

    //Case 1: if there is no free block, we need to add one, and then link it to our superblock psuper specifically
    //Case 2: if the last free block is full, so its capacity is at the number of collector nodes it can have, then add a new free block
    //Case 3: if the first free block has any entries left; reason is there is a possiblity that we truly only have one free block that has any collector node space avalible.

}
