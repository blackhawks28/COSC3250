/* fileDelete.c - fileDelete */
/* Copyright (C) 2008, Marquette University.  All rights reserved. */
/**
* COSC 3250 - Project 10
* Deletes file by resetting its values in filetab and rewriting the information onto the disk.
* @authors [Chris Piszczek]
* @authors [Dennis Burmeister]
* Instructor [Dr. Rubya]
* TA-BOT:MAILTO [christian.piszczek@marquette.edu]
* TA-BOT:MAILTO [dennis.burmeister@marquette.edu]
*/

#include <kernel.h>
#include <memory.h>
#include <file.h>

/*------------------------------------------------------------------------
 * fileDelete - Delete a file.
 *------------------------------------------------------------------------
 */
devcall fileDelete(int fd)
{
    // TODO: Unlink this file from the master directory index,
    //  and return its space to the free disk block list.
    //  Use the superblock's locks to guarantee mutually exclusive
    //  access to the directory index.

    //check for errors; similar to filecreate; check the limit of fd, and check if supertab is null, check state of filetab[fd]
    //call sbfreeblock
    //change filetab[fd], make sure to use semaphores, change the state to freestate since you delete it
    if((isbadfd(fd) == TRUE) || (supertab == NULL) || (filetab == NULL)){
        return SYSERR;
    }
    wait(supertab->sb_dirlock);//locks up

    filetab[fd].fn_length = 0;//reset length
    filetab[fd].fn_cursor = 0;//reset cursor
    filetab[fd].fn_name[0] = '\0';//reset name
    filetab[fd].fn_state = FILE_FREE;//set state to free

    if(sbFreeBlock(supertab, supertab->sb_dirlst->db_fnodes[fd].fn_blocknum) == SYSERR){
        signal(supertab->sb_dirlock);
        return SYSERR;
    }
    //diskwrite?
    //diskseek?
    seek(DISK0,supertab->sb_dirlst->db_blocknum);//find disk
    write(DISK0, supertab->sb_dirlst, sizeof(struct dirblock));//write to disk with new reset info
    signal(supertab->sb_dirlock);//unlock
    return OK;
}
