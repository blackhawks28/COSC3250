/**
 * @file     xsh_test.c
 * @provides xsh_test
 *
 */
/* Embedded XINU, Copyright (C) 2009.  All rights reserved. */
/**
* COSC 3250 - Project 10
* Test cases to run in the mips-console
* @authors [Chris Piszczek]
* @authors [Dennis Burmeister]
* Instructor [Dr. Rubya]
* TA-BOT:MAILTO [christian.piszczek@marquette.edu]
* TA-BOT:MAILTO [dennis.burmeister@marquette.edu]
*/
#include <xinu.h>
#include <file.h>

/**
 * Shell command (test) is testing hook.
 * @param args array of arguments
 * @return OK for success, SYSERR for syntax error
 */


void PrintFreeList(void)
{
    int i;
    struct freeblock *fb = NULL;
    if ((NULL == supertab) || (NULL == (fb = supertab->sb_freelst)))
    {
        printf("Freelst: null\n");
        return;
    }

    printf("Freelst collector nodes:\n");
    while (fb)
    {
        printf("Blk %3d, cnt %3d = ", fb->fr_blocknum, fb->fr_count);
        for (i = 0; (i < fb->fr_count) && (i < 10); i++)
        {
            printf("[%03d]", fb->fr_free[i]);
        }
        if (fb->fr_count >= 10)
        {
            printf("...[%03d]", fb->fr_free[fb->fr_count - 1]);
        }
        printf("\n");
        fb = fb->fr_next;
    }
}

command xsh_test(int nargs, char *args[])
{
    //TODO: Test your O/S.

    //just write normal testcases like in previous assignments; make switch cases, then in mips-console go to test, and it should be visible.
    //Make a test case like Brads where it cycles through the entire file system, makes a new file, then deletes it, makes a new file, then deletes, and keep going until
    //the entire file blocks are essentially reversed.

    printf("Type l to run the loop test that tests the entirety of the directory\r\n");
    printf("Type 0 to create and delete files\r\n");

    char c;
    int x, y, z, p;
    int file[256];
    int blk;

    c = kgetc();
    switch(c){
        case 'l':
            y = 0;
            z = 0;
            while(1){

                x = sbGetBlock(supertab);
                sbFreeBlock(supertab, x);
                PrintFreeList();
            }
            blk = sbGetBlock(supertab);
            printf("sbGetBlock = %d\r\n", blk);
            sbFreeBlock(supertab, blk);
        break;

        case '0':
            PrintFreeList();//Initial free list organization

            x = fileCreate("1");
            y = fileCreate("2");
            z = fileCreate("3");
            p = fileCreate("4");
            printf("Created 4 files \r\n");

            PrintFreeList();//Free list after making 4 files

            fileDelete(x);
            fileDelete(y);
            fileDelete(z);
            fileDelete(p);
            printf("4 Files deleted \r\n");

            PrintFreeList();//Free list after deleting the 4 files
        break;

        case '1':

        break;
    }

    return OK;
}
